**CREDIT CARD RISK MANAGEMENT**

Utilizing HTML, CSS, and JavaScript, I developed a frontend website that encompasses a login page tailored for bank employees. 
Following a successful verification process, employees are seamlessly redirected to a subsequent page. 
This page solicits the customer's userID, subsequently displaying transaction information through graphical representations. 
An additional feature embedded within the platform involves the utilization of a machine learning model, enabling the assessment of credit card risk as part of the overall process.

