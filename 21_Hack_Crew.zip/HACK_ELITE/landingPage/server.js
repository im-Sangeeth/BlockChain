const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const ejs = require('ejs');

const path = require('path'); // Import the 'path' module

const app = express();
const port = 3001;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect('mongodb+srv://suganthan0001:vithya0001@cluster0.8dhzafz.mongodb.net/loginform?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Mongoose connected');
})
.catch((error) => {
  console.error('Mongoose connection error: ' + error);
});

const UserSchema = new mongoose.Schema({
  userId: String,
  password: String,
  uniqueId: String
});

const User = mongoose.model('User', UserSchema);

const user1 = new User({
  userId: "user",
  password: "12345",
  uniqueId: "54321"
})

// user1.save(); 

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.post('/loginForm', (req,res) => {
  res.sendFile(path.join(__dirname,('public/login.html')));
});

app.post('/login', async (req, res) => {
  const userId = req.body.userId;
  const password = req.body.password;
  const uniqueId = req.body.unique;
  try {
    console.log(`Searching for user with userId: ${userId} , password: ${password} , uniqueID: ${uniqueId}`);
    const user = await User.findOne({ userId, password, uniqueId });
    console.log(`Found user:`, user);
    if (user) {
      // res.sendFile(path.join(__dirname, 'public/customerId.html'));
      res.redirect('http://localhost:9000/');
    } else {
      res.sendFile(path.join(__dirname, 'public/invalidCredentials.html'));
    }
  } catch (error) {
    res.status(500).send('Internal server error');
  }
}); 

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
